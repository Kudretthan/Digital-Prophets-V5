export * from "../src/lib/freighter";
export { default } from "../src/lib/freighter";
