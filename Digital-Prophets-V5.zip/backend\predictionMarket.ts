export * from "../src/lib/predictionMarket";
export { default } from "../src/lib/predictionMarket";
