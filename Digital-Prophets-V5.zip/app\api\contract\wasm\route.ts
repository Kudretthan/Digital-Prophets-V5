import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET() {
  try {
    const wasmPath = path.join(
      process.cwd(),
      '..',
      'contracts',
      'target',
      'wasm32-unknown-unknown',
      'release',
      'prediction_market.wasm'
    );

    if (!fs.existsSync(wasmPath)) {
      return NextResponse.json(
        { error: 'WASM file not found at ' + wasmPath },
        { status: 404 }
      );
    }

    const wasmData = fs.readFileSync(wasmPath);

    return new NextResponse(wasmData, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Length': wasmData.length.toString(),
      },
    });
  } catch (error) {
    console.error('Error serving WASM:', error);
    return NextResponse.json(
      { error: 'Failed to serve WASM file' },
      { status: 500 }
    );
  }
}
