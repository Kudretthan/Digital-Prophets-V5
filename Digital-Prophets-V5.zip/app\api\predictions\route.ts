import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { Prediction } from '@/types';

export async function GET() {
  try {
    const { data, error } = await supabase
      .from('predictions')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;

    // Return data or demo predictions if empty
    if (!data || data.length === 0) {
      return NextResponse.json([
        {
          id: 1,
          title: 'Bitcoin 50K altında olacak mı?',
          description: 'Bitcoin fiyatı Aralık sonuna kadar 50K altında kalır mı?',
          category: 'crypto',
          created_by: 'Digital Seers',
          target_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active',
          yes_amount: 250,
          no_amount: 150,
          resolved: false,
          result: null,
          probability: 40,
        },
        {
          id: 2,
          title: 'S&P 500 yeni rekor kıracak mı?',
          description: 'S&P 500 Aralık içinde yeni all-time high yapacak mı?',
          category: 'stocks',
          created_by: 'Digital Seers',
          target_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active',
          yes_amount: 300,
          no_amount: 200,
          resolved: false,
          result: null,
          probability: 65,
        },
        {
          id: 3,
          title: 'Dolar/TL 30 olmayacak mı?',
          description: 'Dolar/Türk Lirası kuru Ocak sonuna kadar 30 altında kalır mı?',
          category: 'forex',
          created_by: 'Digital Seers',
          target_date: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active',
          yes_amount: 180,
          no_amount: 320,
          resolved: false,
          result: null,
          probability: 35,
        },
      ]);
    }

    return NextResponse.json(data || []);
  } catch (error) {
    console.error('Failed to fetch predictions:', error);
    // Return demo data on error
    return NextResponse.json([
      {
        id: 1,
        title: 'Bitcoin 50K altında olacak mı?',
        description: 'Bitcoin fiyatı Aralık sonuna kadar 50K altında kalır mı?',
        category: 'crypto',
        yes_amount: 250,
        no_amount: 150,
        resolved: false,
        probability: 40,
      },
    ]);
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    const newPrediction = {
      title: data.title,
      description: data.description,
      category: data.category,
      created_by: data.createdBy || 'Anonymous',
      target_date: new Date(data.targetDate).toISOString(),
      status: 'active',
      technical_analysis: data.technicalAnalysis,
      emotional_analysis: data.emotionalAnalysis,
      total_xlm_staked: data.initialxlm,
      supporting_xlm: Math.floor(data.initialxlm * 0.6),
      opposing_xlm: Math.floor(data.initialxlm * 0.4),
      success_rate: 50,
      probability: 50,
      odds: 1.5,
      result: null,
    };

    const { data: createdPrediction, error } = await supabase
      .from('predictions')
      .insert([newPrediction])
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(createdPrediction, { status: 201 });
  } catch (error) {
    console.error('Failed to create prediction:', error);
    return NextResponse.json(
      { error: 'Failed to create prediction' },
      { status: 500 }
    );
  }
}
